-- MySQL dump 10.19  Distrib 10.3.29-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: rhys19_cad
-- ------------------------------------------------------
-- Server version	10.3.29-MariaDB-0ubuntu0.20.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `rhys19_cad`
--


--
-- Table structure for table `10_codes`
--

DROP TABLE IF EXISTS `10_codes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `10_codes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `code` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `10_codes`
--

LOCK TABLES `10_codes` WRITE;
/*!40000 ALTER TABLE `10_codes` DISABLE KEYS */;
INSERT INTO `10_codes` VALUES (1,'10-6 (Busy / Away)'),(2,'10-7 (Out of Service)'),(3,'10-8 (In Service)'),(4,'10-11 (Active Traffic Stop)'),(5,'10-15 (Transporting Suspect)'),(6,'10-23 (Arrived On Scene)'),(7,'10-41 (Start Tour of Duty)'),(8,'10-42 (End Tour of Duty)'),(9,'10-80 (In Pursuit)'),(10,'10-97 (En Route)');
/*!40000 ALTER TABLE `10_codes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `911call_log`
--

DROP TABLE IF EXISTS `911call_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `911call_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `dispatcher` varchar(64) NOT NULL,
  `action` varchar(355) NOT NULL,
  `timestamp` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `911call_log`
--


--
-- Table structure for table `911calls`
--

DROP TABLE IF EXISTS `911calls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `911calls` (
  `call_id` int(11) NOT NULL AUTO_INCREMENT,
  `caller_id` int(11) NOT NULL,
  `call_description` varchar(355) NOT NULL,
  `call_location` varchar(128) NOT NULL,
  `call_postal` varchar(64) DEFAULT NULL,
  `call_status` varchar(534) NOT NULL DEFAULT 'NOT ASSIGNED',
  `call_timestamp` text NOT NULL,
  `call_isPriority` enum('false','true') DEFAULT 'false',
  PRIMARY KEY (`call_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `911calls`
--


--
-- Table structure for table `arrest_reports`
--

DROP TABLE IF EXISTS `arrest_reports`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `arrest_reports` (
  `arrest_id` int(11) NOT NULL AUTO_INCREMENT,
  `arresting_officer` varchar(126) NOT NULL,
  `timestamp` varchar(64) NOT NULL,
  `suspect` varchar(126) NOT NULL,
  `suspect_id` int(11) NOT NULL,
  `summary` text NOT NULL,
  PRIMARY KEY (`arrest_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `arrest_reports`
--


--
-- Table structure for table `assigned_callunits`
--

DROP TABLE IF EXISTS `assigned_callunits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `assigned_callunits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `call_id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `assigned_callunits`
--


--
-- Table structure for table `bolos`
--

DROP TABLE IF EXISTS `bolos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bolos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` varchar(128) NOT NULL,
  `type` text NOT NULL,
  `reason` text NOT NULL,
  `description` text NOT NULL,
  `location` text NOT NULL,
  `created_by` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bolos`
--

--
-- Table structure for table `characters`
--

DROP TABLE IF EXISTS `characters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `characters` (
  `character_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(64) NOT NULL,
  `last_name` varchar(64) NOT NULL,
  `date_of_birth` varchar(126) NOT NULL,
  `address` text NOT NULL,
  `height` varchar(36) NOT NULL,
  `eye_color` varchar(36) NOT NULL,
  `hair_color` varchar(36) NOT NULL,
  `medical_notes` varchar(120) NOT NULL DEFAULT 'No notes on record',
  `blood_type` varchar(12) NOT NULL,
  `sex` varchar(12) NOT NULL,
  `race` varchar(60) NOT NULL,
  `weight` varchar(36) NOT NULL,
  `owner_id` int(11) NOT NULL,
  `owner_name` varchar(128) NOT NULL,
  `status` varchar(36) NOT NULL DEFAULT 'Enabled',
  `license_driver` varchar(36) NOT NULL DEFAULT 'None',
  `license_pilot` varchar(36) NOT NULL DEFAULT 'None',
  `license_firearm` varchar(36) NOT NULL DEFAULT 'None',
  PRIMARY KEY (`character_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `characters`
--


--
-- Table structure for table `companies`
--

DROP TABLE IF EXISTS `companies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `companies` (
  `c_id` int(11) NOT NULL AUTO_INCREMENT,
  `c_name` varchar(64) NOT NULL,
  `c_desc` varchar(255) NOT NULL,
  `c_owner` varchar(64) NOT NULL,
  `c_ownerid` int(11) NOT NULL,
  `created_on` text NOT NULL,
  PRIMARY KEY (`c_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companies`
--


--
-- Table structure for table `identities`
--

DROP TABLE IF EXISTS `identities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identities` (
  `identity_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(126) NOT NULL,
  `callsign` text DEFAULT NULL,
  `department` varchar(64) NOT NULL,
  `division` varchar(36) DEFAULT NULL,
  `division_type` text DEFAULT NULL,
  `supervisor` varchar(36) NOT NULL DEFAULT 'No',
  `created_on` varchar(126) NOT NULL,
  `user` int(11) NOT NULL,
  `user_name` varchar(128) NOT NULL,
  `status` enum('Active','Approval Needed','Suspended') NOT NULL DEFAULT 'Active',
  PRIMARY KEY (`identity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `identities`
--


--
-- Table structure for table `leo_division`
--

DROP TABLE IF EXISTS `leo_division`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `leo_division` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` text NOT NULL,
  `name` varchar(36) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `leo_division`
--

LOCK TABLES `leo_division` WRITE;
/*!40000 ALTER TABLE `leo_division` DISABLE KEYS */;
INSERT INTO `leo_division` VALUES (11,'Local','Police');
/*!40000 ALTER TABLE `leo_division` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `logs`
--

DROP TABLE IF EXISTS `logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `action` varchar(300) NOT NULL DEFAULT 'NaN',
  `username` varchar(128) NOT NULL DEFAULT 'NaN',
  `timestamp` varchar(364) NOT NULL DEFAULT 'NaN',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=275 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `logs`
--


--
-- Table structure for table `news`
--

DROP TABLE IF EXISTS `news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `news` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(64) NOT NULL,
  `message` text NOT NULL,
  `datetime` varchar(64) NOT NULL,
  `author` varchar(64) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `news`
--

LOCK TABLES `news` WRITE;
/*!40000 ALTER TABLE `news` DISABLE KEYS */;
INSERT INTO `news` VALUES (1,'Welcome to CAD v2.2','CAD v2.2 brings a bunch of new aspects to the system. We\'ve improved the UI, accessibility and improved some minor security issues.\r\n\r\n<h4>General Improvements</h4>\r\n - We\'ve made it easier to customize and add options to your system! You can view the file in <code>inc/utilities.json</code>.\r\n\r\n - We\'ve fixed the discord webhooks issue, as well as changed to embed based messages\r\n\r\n - Added new pilots license and Bail Bonds module. Includes new jurisdictional division assignment\r\n\r\n<h4>Future Updates</h4>\r\nUpdates will still be pushed for the CAD v2 system. Updates will be more frequent and include more visual and functional elements on top of the security and optimization of the system itself.\r\n\r\n<h4>We\'d love to hear what you want!</h4>\r\nLet us know!','10/17/2020 01:47:46 AM','Hybrid Systems');
/*!40000 ALTER TABLE `news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `on_duty`
--

DROP TABLE IF EXISTS `on_duty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `on_duty` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `department` varchar(64) NOT NULL,
  `division` varchar(64) DEFAULT NULL,
  `status` varchar(64) NOT NULL DEFAULT '10-41',
  `uid` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `on_duty`
--

--
-- Table structure for table `passwordreset`
--

DROP TABLE IF EXISTS `passwordreset`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `passwordreset` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` text NOT NULL,
  `code` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `passwordreset`
--

--
-- Table structure for table `servers`
--

DROP TABLE IF EXISTS `servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `servers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `aop` varchar(64) NOT NULL DEFAULT 'Sandy Shores',
  `priority` int(11) NOT NULL DEFAULT 0,
  `se` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `servers`
--

LOCK TABLES `servers` WRITE;
/*!40000 ALTER TABLE `servers` DISABLE KEYS */;
INSERT INTO `servers` VALUES (1,'Server 1','None Set',0,0);
/*!40000 ALTER TABLE `servers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `settings`
--

DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `settings` (
  `setting_id` int(11) NOT NULL AUTO_INCREMENT,
  `site_name` varchar(255) NOT NULL,
  `account_validation` varchar(36) NOT NULL DEFAULT 'false',
  `identity_validation` varchar(36) NOT NULL DEFAULT 'false',
  `steam_required` varchar(36) NOT NULL DEFAULT 'false',
  `steam_domain` text DEFAULT NULL,
  `steam_api` text DEFAULT NULL,
  `discord_alerts` enum('true','false') NOT NULL DEFAULT 'false',
  `discord_webhook` text DEFAULT NULL,
  `display_aop` varchar(255) NOT NULL DEFAULT 'true',
  `timezone` varchar(128) NOT NULL DEFAULT 'America/Los_Angeles',
  `civ_side_warrants` varchar(36) NOT NULL DEFAULT 'false',
  `civ_side_layout` enum('regular','tabs') NOT NULL DEFAULT 'regular',
  `add_warrant` enum('all','supervisor') NOT NULL DEFAULT 'supervisor',
  `group_unverifiedGroup` int(11) NOT NULL DEFAULT 2,
  `group_verifiedGroup` int(11) NOT NULL DEFAULT 3,
  `group_banGroup` int(11) NOT NULL DEFAULT 1,
  `livemap_url` text DEFAULT NULL,
  `penalcode_url` text DEFAULT NULL,
  `civ_char_limit` int(11) NOT NULL DEFAULT 3,
  PRIMARY KEY (`setting_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `settings`
--

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'Hybrid CAD/MDT','yes','no','false','null','null','true','','true','America/Chicago','true','tabs','all',2,3,1,'null','',5);
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shift_logs`
--

DROP TABLE IF EXISTS `shift_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `i_id` int(11) NOT NULL,
  `s_start` text NOT NULL,
  `s_end` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=107 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shift_logs`
--


--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL AUTO_INCREMENT,
  `officer` varchar(126) NOT NULL,
  `suspect` varchar(126) NOT NULL,
  `suspect_id` int(11) NOT NULL,
  `ticket_timestamp` varchar(355) NOT NULL,
  `reasons` text NOT NULL,
  `location` text NOT NULL,
  `postal` int(255) NOT NULL,
  `amount` varchar(24) NOT NULL,
  PRIMARY KEY (`ticket_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--


--
-- Table structure for table `usergroups`
--

DROP TABLE IF EXISTS `usergroups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(64) NOT NULL,
  `isBanned` enum('false','true') NOT NULL DEFAULT 'false',
  `panel_access` enum('false','true') NOT NULL DEFAULT 'true',
  `staff_approveUsers` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_access` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_viewUsers` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_editUsers` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_editAdmins` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_siteSettings` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_banUsers` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_SuperAdmin` enum('false','true') NOT NULL DEFAULT 'false',
  `staff_newsAccess` enum('true','false') NOT NULL DEFAULT 'false',
  `default_group` enum('false','true') NOT NULL DEFAULT 'false',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroups`
--

LOCK TABLES `usergroups` WRITE;
/*!40000 ALTER TABLE `usergroups` DISABLE KEYS */;
INSERT INTO `usergroups` VALUES (1,'Banned','true','false','false','false','false','false','false','false','false','false','false','true'),(2,'Unverified','false','false','false','false','false','false','false','false','false','false','false','true'),(3,'User','false','true','false','false','false','false','false','false','false','false','false','true'),(4,'Moderator','false','true','true','true','true','false','false','false','false','false','false','true'),(5,'Admin','false','true','true','true','true','true','false','false','true','false','false','true'),(6,'Super Admin','false','true','true','true','true','true','true','true','true','true','true','true'),(7,'Owner','false','true','true','true','true','true','true','true','true','true','true','false');
/*!40000 ALTER TABLE `usergroups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(36) NOT NULL,
  `password` varchar(255) NOT NULL,
  `email` varchar(164) NOT NULL,
  `usergroup` int(11) DEFAULT NULL,
  `join_date` varchar(126) NOT NULL,
  `join_ip` varchar(126) NOT NULL,
  `last_ip` varchar(36) DEFAULT NULL,
  `steam_id` varchar(355) DEFAULT NULL,
  `steam_hex` text NOT NULL,
  `avatar` varchar(355) DEFAULT 'assets/images/users/placeholder.png',
  `ban_reason` varchar(126) DEFAULT NULL,
  `theme` varchar(64) NOT NULL DEFAULT 'default',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `username` (`username`),
  KEY `usergroup` (`usergroup`),
  CONSTRAINT `users_ibfk_1` FOREIGN KEY (`usergroup`) REFERENCES `usergroups` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--


--
-- Table structure for table `vehicles`
--

DROP TABLE IF EXISTS `vehicles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehicles` (
  `vehicle_id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_plate` varchar(8) DEFAULT NULL,
  `vehicle_color` varchar(36) NOT NULL,
  `vehicle_model` varchar(36) NOT NULL,
  `vehicle_is` varchar(36) NOT NULL,
  `vehicle_rs` varchar(36) NOT NULL,
  `vehicle_vin` varchar(17) NOT NULL,
  `vehicle_owner` int(11) NOT NULL,
  `vehicle_ownername` varchar(126) NOT NULL,
  `vehicle_isStolen` enum('true','false') NOT NULL DEFAULT 'false',
  `vehicle_isImpounded` enum('true','false') NOT NULL DEFAULT 'false',
  `vehicle_impoundedTill` text DEFAULT NULL,
  `vehicle_impoundedCount` int(11) NOT NULL DEFAULT 0,
  `vehicle_status` varchar(36) NOT NULL DEFAULT 'Enabled',
  PRIMARY KEY (`vehicle_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicles`
--


--
-- Table structure for table `warrants`
--

DROP TABLE IF EXISTS `warrants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warrants` (
  `warrant_id` int(11) NOT NULL AUTO_INCREMENT,
  `issued_on` varchar(355) NOT NULL,
  `signed_by` varchar(128) NOT NULL,
  `reason` text NOT NULL,
  `notes` text NOT NULL DEFAULT 'None',
  `wanted_person` varchar(128) NOT NULL,
  `wanted_person_id` int(11) NOT NULL,
  `wanted_status` varchar(36) NOT NULL DEFAULT 'WANTED',
  PRIMARY KEY (`warrant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `warrants`
--


--
-- Table structure for table `weapons`
--

DROP TABLE IF EXISTS `weapons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `weapons` (
  `wpn_id` int(11) NOT NULL AUTO_INCREMENT,
  `wpn_type` varchar(126) NOT NULL,
  `wpn_serial` varchar(10) NOT NULL,
  `wpn_owner` int(11) NOT NULL,
  `wpn_ownername` varchar(255) NOT NULL,
  `wpn_rpstatus` varchar(255) NOT NULL DEFAULT 'Valid',
  PRIMARY KEY (`wpn_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `weapons`
--


/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-09 12:13:08
