<?php
$url['index'] = "index.php";
$url['register'] = "register.php";
$url['login'] = "login.php";
$url['logout'] = "logout.php";
$url['civilian'] = "civilian.php";
$url['steam-required'] = "steam-required.php";
$url['leo'] = "leo.php";
$url['bailbonds'] = "bailbonds.php";
$url['fire'] = "fire.php";
$url['dispatch'] = "dispatch.php";
$url['staff'] = "staff.php";
$url['settings'] = "user-settings.php";
$url['user-identities'] = "user-identities.php";
?>
