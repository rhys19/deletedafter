<body>
           <div class="account-pages mt-5 mb-5">
          <div class="container">
              <div class="row justify-content-center">
                  <div class="col-md-8 col-lg-6 col-xl-5">
                      <div class="card">
                          <div class="card-body p-4">
                              <div class="text-center w-75 m-auto">
                                  <a href="index.php">
                                      <span><strong><font size="5"> <p> Reset your password </p> </font></strong></span>
                                  </a>
                                  <p class="text-muted mb-4 mt-3">An email will be sent with further instructions on resetting your lost password.</p>
                              </div>

                              <form id="userReset" action="inc/backend/user/auth/userReset.php" method="POST">

                                  <div class="form-group mb-3">
                                      <label for="Email">Email</label>
                                      <input class="form-control" type="text" name="email" required="" placeholder="example@email.com">
                                  </div>
                                  <div class="form-group mb-0 text-center">
                                      <button class="btn btn-primary btn-block" type="submit"> Reset </button>
                                  </div>
                              </form>
                          </div> <!-- end card-body -->
                      </div>
                      <!-- end card -->

                      <div class="row mt-3">
                          <div class="col-12 text-center">
						   <p class="text-muted">Back to login page: <a href="login.php" class="text-primary font-weight-medium ml-1">Click here</a></p>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
      </div>
