<?php
require_once 'inc/connect.php';
require_once 'inc/config.php';
?>

<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-6">
               <?php echo $settingsRow['site_name']; ?> | <strong><a href="https://discord.gg/wSW74Xn">Hybrid Systems</a></strong>
            </div>
            <div class="col-md-6">
                <div class="text-md-right footer-links d-none d-sm-block">
                    v<?php echo $version; ?>
                </div>
            </div>
        </div>
    </div>
</footer>
