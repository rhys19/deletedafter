        <!-- jQuery  -->
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/plugins/toastr/toastr.min.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/plugins/jquery-knob/jquery.knob.js"></script>
        <script src="assets/plugins/bootstrap-datepicker/dist/js/bootstrap-datepicker.min.js"></script>
        <!-- Required datatable js -->
        <script src="assets/plugins/switchery/switchery.js"></script>
        <script src="assets/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/plugins/datatables/dataTables.bootstrap4.min.js"></script>
        <!-- Responsive examples -->
        <script src="assets/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/plugins/datatables/responsive.bootstrap4.min.js"></script>
        <!-- Selection table -->
        <script src="assets/plugins/datatables/dataTables.select.min.js"></script>
        <!-- Form wizard -->
        <script src="assets/plugins/bootstrap-wizard/jquery.bootstrap.wizard.js"></script>
        <script src="assets/plugins/jquery-validation/dist/jquery.validate.min.js"></script>
         <script>
           // Default Datatable
           $('#datatable').DataTable();
           $('#datatable2').DataTable();
           $('#datatable3').DataTable();
           $('#datatable4').DataTable();
            var _0x2e0d=['font-size:64px;color:#ff1a1a;text-shadow:0\x201px\x200#ff0000,0\x202px\x200\x20\x20#cc0000\x20,0\x203px\x200\x20\x20#b30000\x20,0\x204px\x200\x20\x20#9a0000\x20,0\x205px\x200\x20\x20#810000\x20,0\x206px\x201px\x20rgba(0,0,0,.1),0\x200\x205px\x20rgba(0,0,0,.1),0\x201px\x203px\x20rgba(0,0,0,.3),0\x203px\x205px\x20rgba(0,0,0,.2),0\x205px\x2010px\x20rgba(0,0,0,.25),0\x2010px\x2010px\x20rgba(0,0,0,.2),0\x2020px\x2020px\x20rgba(0,0,0,.15);','%cI\x20see\x20you\x27re\x20looking\x20around;\x20very\x20well.\x20Since\x20I\x20have\x20you\x20here,\x20freeCAD\x20is\x20an\x20open\x20source\x20project\x20created\x20by\x20Hybrid\x20Systems.','color:#000;font-size:20px;','log'];(function(_0x481bb7,_0x306919){var _0xf0a3be=function(_0x39725e){while(--_0x39725e){_0x481bb7['push'](_0x481bb7['shift']());}};_0xf0a3be(++_0x306919);}(_0x2e0d,0xab));var _0x45e8=function(_0x94f276,_0x2009d8){_0x94f276=_0x94f276-0x0;var _0x365253=_0x2e0d[_0x94f276];return _0x365253;};console[_0x45e8('0x0')]('%cHello\x20there.',_0x45e8('0x1'));console[_0x45e8('0x0')](_0x45e8('0x2'),_0x45e8('0x3'));           $('#datatable4').DataTable();
           $('#datatable5').DataTable();
                // Date Picker
            jQuery('#datepicker').datepicker();
            jQuery('#datepicker-autoclose').datepicker({
                autoclose: true,
                todayHighlight: true
            });
            jQuery('#datepicker-inline').datepicker();
        </script>
        <script src="assets/js/custom.js?v=<?php echo $assets_ver ?>"></script>
	</body>
</html>
