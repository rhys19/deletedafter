<?php

session_name('hydrid');
session_start();
require_once '../../../connect.php';

require_once '../../../config.php';

header('Content-Type: application/json');

$username = !empty($_GET['username']) ? trim($_GET['username']) : null;
$passwordAttempt = !empty($_GET['password']) ? trim($_GET['password']) : null;

$sql = "SELECT * FROM users WHERE username = :username";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':username', $username);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);

$validPassword = password_verify($passwordAttempt, $user['password']);
if ($user === false) {
	echo json_encode(array(
	'response' => 400,
	'content' => 'username'
	));
	exit();
}
if ($validPassword) {
	echo json_encode(array(
	'response' => 200,
	'content' => 'valid'
	));
	exit();
} else {
	echo json_encode(array(
	'response' => 400,
	'content' => 'password'
	));
	exit();

}
