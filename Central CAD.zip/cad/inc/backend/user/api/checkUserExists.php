<?php
session_name('hydrid');
session_start();
require '../../../connect.php';

require '../../../config.php';

header('Content-Type: application/json');


$username = !empty($_GET['username']) ? $_GET['username'] : null;
$password = !empty($_GET['password']) ? $_GET['password'] : null;

$sql = "SELECT * FROM users WHERE username = :username";
$stmt = $pdo->prepare($sql);
$stmt->bindValue(':username', $username);
$stmt->execute();
$user = $stmt->fetch(PDO::FETCH_ASSOC);
if ($user === false) {
  echo 'false';
  exit();

} else {
  
  $passwordValid = password_verify($password, $user['password']);
  if ($passwordValid) {
  	if ($settings['account_validation'] === "yes" && $user['usergroup'] === $settings['unverifiedGroup']) {
     echo json_encode(array(
	'response' => 400,
	'content' => 'verify'
     ));
	   exit();
  	} else {
     echo json_encode(array(
	'response' => 200,
	'content' => dbquery('SELECT * FROM users')
     ));

	exit();
     }
     echo json_encode(array(
	'response' => 400,
	'content' => 'password'
     ));
     exit();
  }
     echo json_encode(array(
	'response' => 400,
	'content' => 'password'
     ));
     exit();

}
