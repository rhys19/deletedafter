<?php
session_name('hydrid');
session_start();

$aop_status = !empty($_GET['FaxCurAOP']) ? trim($_GET)['FaxCurAOP']) : null;

	$error = array();
	$sql = "INSERT INTO aop (aop) VALUES (
		:aop
		)";
	$stmt = $pdo->prepare($sql);
	$stmt->bindValue(':caller_id', $aop_status);
	$result = $stmt->execute();
	if ($result) {
	    if ($settings['discord_alerts'] === 'true') {
	        discordAlert('**AOP Has Changed**
		**New AOP Is:** ' . $aop_status . '.');
	    }
	    $error['msg'] = "";
	    echo json_encode($error);
	    exit();
	}
}