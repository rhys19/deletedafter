<?php
session_name('hydrid');
session_start();
require '../../../connect.php';

require '../../../config.php';

$sql = "SELECT aop FROM servers";
$stmt = $pdo->prepare($sql);
$stmt->execute();
$row = $stmt->fetch(PDO::FETCH_ASSOC);

echo $row['aop'];
?>