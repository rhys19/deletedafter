<?php
session_name('hydrid');
session_start();
require '../../../connect.php';

require '../../../config.php';

require '../../../backend/user/auth/userIsLoggedIn.php';

// Makes sure the person actually has a character set
if ($_SESSION['on_duty'] === "Dispatch" || $_SESSION['on_duty'] === "LEO") {
    // Page PHP

    $type = !empty($_POST['type']) ? trim($_POST['type']) : null;
    $type = strip_tags($_POST['type']); 

    $reason = !empty($_POST['reason']) ? trim($_POST['reason']) : null;
    $reason = strip_tags($_POST['reason']); 

    $description = !empty($_POST['description']) ? trim($_POST['description']) : null;
    $description = strip_tags($_POST['description']);

    $location = !empty($_POST['location']) ? trim($_POST['location']) : null;
    $location = strip_tags($_POST['location']); 

    $error = array();

    $sql = "INSERT INTO bolos (created_on, type, reason, description, location, created_by) VALUES (
		:created_on,
        :type,
        :reason,
		:description,
        :location,
		:created_by
		)";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':created_on', $us_date . ' ' . $time);
    $stmt->bindValue(':type', $type);
    $stmt->bindValue(':reason', $reason);
    $stmt->bindValue(':description', $description);
    $stmt->bindValue(':location', $location);
    $stmt->bindValue(':created_by', $_SESSION['identity_id']);
    $result = $stmt->execute();
    if ($result) {
        if ($settings['discord_alerts'] === 'true') {
            discordAlert('**New Bolo Submitted**
		Reporting Officer : `' . $_SESSION['identity_name'] . '`
        Type : `' . $type . '`
        Reason : `'. ucfirst($reason) .'`
        Description : `'. $description .'`
		Submitted : `' . $datetime . '`');
        }
        $error['msg'] = "";
        echo json_encode($error);
        exit();
    }
}
