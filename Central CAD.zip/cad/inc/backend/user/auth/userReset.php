<?php
session_name('hydrid');
session_start();
require_once '../../../connect.php';

require_once '../../../config.php';

$email = !empty($_POST['email']) ? trim($_POST['email']) : null;

$email = strip_tags($email);

$sql1 = "SELECT * FROM users WHERE email = :email";
$stmt1 = $pdo->prepare($sql1);
$stmt1->bindValue(':email', $email);
$stmt1->execute();
$user = $stmt1->fetch(PDO::FETCH_ASSOC);
if($user === false){
    $exists = false;
} else {
    $exists = true;
}

$sql3 = "SELECT * FROM passwordreset WHERE email = :email";
$stmt3 = $pdo->prepare($sql3);
$stmt3->bindValue(':email', $email);
$stmt3->execute();
$rows = $stmt3->rowCount();
if($rows === 0) {
    $alreadyintable = false;
} else {
    $alreadyintable = true;
}

if($exists === true){
    if($alreadyintable === false){
        $sql2 = "INSERT INTO passwordreset (email, code) VALUES (:email, :code)";
        $stmt2 = $pdo->prepare($sql2);
        $stmt2->bindValue(':email', $email);
        $stmt2->bindValue(':code', uniqid(true));
        $stmt2->execute();
        $return = $stmt2->fetch(PDO::FETCH_ASSOC);
        if ($return === false) {
                $error['msg'] = "";
                echo json_encode($error);
                $headers = "MIME-Version: 1.0" . "\r\n";
$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

// More headers
$headers .= 'From: <webmaster@example.com>' . "\r\n";
$headers .= 'Cc: myboss@example.com' . "\r\n";
                mail("nippleboob69@hotmail.com", "Password Reset", "So you wanna reset your password, huh? well.. ", $headers);
                exit();
        } else {
            $error['msg'] = "Unhandled error occured";
            echo json_encode($error);
            exit();
        }
    } else {
        $error['msg'] = "You've already requested a password change";
        echo json_encode($error);
        exit();
    }
} else {
    $error['msg'] = "No account associated with that email exists";
    echo json_encode($error);
    exit();
}
