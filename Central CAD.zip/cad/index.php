<?php
session_name('hydrid');
session_start();
require_once 'inc/connect.php';

require_once 'inc/config.php';

require_once 'inc/backend/user/auth/userIsLoggedIn.php';
$page['name'] = 'Home';
$stats['users'] = null;
$stats['civ'] = null;
$stats['ems'] = null;
$stats['news_count'] = null;

$stats['users'] = $pdo->query('select count(*) from users')->fetchColumn();
$stats['aop'] = $pdo->query('select aop from servers')->fetchColumn();
$stats['civ'] = $pdo->query('select count(*) from characters')->fetchColumn();
$stats['ems'] = $pdo->query('select count(*) from identities')->fetchColumn();
$stats['news_count'] = $pdo->query('select count(*) from news')->fetchColumn();
vCheck();
?>
<?php include 'inc/page-top.php'; ?>

<!DOCTYPE html>
<html>
<style>
.tooltip {
  position: relative;
  display: inline-block;
  border-bottom: 1px dotted black;
}

.tooltip .tooltiptext {
  visibility: hidden;
  width: 120px;
  background-color: #555;
  color: #fff;
  text-align: center;
  border-radius: 6px;
  padding: 5px 0;
  position: absolute;
  z-index: 1;
  bottom: 125%;
  left: 50%;
  margin-left: -60px;
  opacity: 0;
  transition: opacity 0.3s;
}

.tooltip .tooltiptext::after {
  content: "";
  position: absolute;
  top: 100%;
  left: 50%;
  margin-left: -5px;
  border-width: 5px;
  border-style: solid;
  border-color: #555 transparent transparent transparent;
}

.tooltip:hover .tooltiptext {
  visibility: visible;
  opacity: 1;
}

.delete:hover {
    cursor: pointer;
    color: red;
}
.edit:hover {
    cursor: pointer;
    color: #006ecf;
}
</style>
<script>
function deleteAnnouncement(str) {
    $.ajax({
        url: "staff.php?a=deleteNews&newsId=" + str,
        cache: false,
        success: function(result) {
            toastr.success('Announcement has been deleted. Please refresh your page', 'System:', {
                timeOut: 10000
            })
        }
    });
}
</script>
<body>
    <?php include 'inc/top-nav.php'; ?>
    <?php
        if (isset($_GET['notify']) && strip_tags($_GET['notify']) === 'steam-linked') {
            clientNotify('success', 'Your Steam Account Has Been Linked.');
        } elseif (isset($_GET['notify']) && strip_tags($_GET['notify']) === 'created') {
          clientNotify('success', 'Successfully created account.');
      }
      ?>
    <!-- CONTENT START -->
    <div class="wrapper m-b-15 m-t-10">
        <div class="container-fluid">
            <div class="row">
                <div class="col">
                    <h4 class="page-title"><?php echo $page['name']; ?></h4>
                </div>
            </div>

            <div class="row">
                <?php if($settings['display_aop'] === 'true'): ?>
                <div class="col col-xs-6 hide-phone">
                    <div class="card-box">
                        <h4 class="header-title mt-0 m-b-30">Current Server AOP</h4>
                        <h2 class="p-t-10 mb-0"><?php echo $stats['aop'] ?> <b class="mdi mdi-24px mdi-map"></b></h2>
                    </div>
                </div>
                <?php endif; ?>
                <div class="col col-xs-6 hide-phone">
                    <div class="card-box">
                        <h4 class="header-title mt-0 m-b-30">Total Users</h4>
                        <h2 class="p-t-10 mb-0"><?php echo $stats['users']; ?> <b class="mdi mdi-24px mdi-account-card-details"></b></h2>
                    </div>
                </div>
                <div class="col col-xs-6 hide-phone">
                    <div class="card-box">
                        <h4 class="header-title mt-0 m-b-30">Total Civilian Profiles</h4>
                        <h2 class="p-t-10 mb-0"><?php echo $stats['civ']; ?> <b class="mdi mdi-24px mdi-account"></b></h2>
                    </div>
                </div>
                <div class="col col-xs-6 hide-phone">
                    <div class="card-box">
                        <h4 class="header-title mt-0 m-b-30">Total Emergency Services Profiles</h4>
                        <h2 class="p-t-10 mb-0"><?php echo $stats['ems']; ?> <b class="mdi mdi-24px mdi-alarm-light"></b></h2>
                    </div>
                </div>

            </div>
            <div class="row">
                <div class="col">
                    <div class="card-box" id="announcements">
                        <h4 class="header-title mt-0 m-b-30">Community Announcements</h4>
                        <?php if ($stats['news_count'] > '0'): ?>
                        <?php
                        $sql = "SELECT * FROM news ORDER BY id desc";
                        $stmt = $pdo->prepare($sql);
                        $stmt->execute();
                        while ($newsDB = $stmt->fetch(PDO::FETCH_ASSOC)) {
                            echo '<div class="card-box text-white bg-success outline-white-c">
                                <h4 class="header-title mt-0 m-b-30"><b class="mdi mdi-verified"> '. $newsDB['title'] .'</b></h4>
                                <p>'.$newsDB['message'].'<br /><hr />
                                <strong>'.$newsDB['datetime'].'</strong> - Posted By: <strong>'.$newsDB['author'].'</strong> <b class="delete mdi mdi-delete" style="font-size: 20px; float: right;" onclick="deleteAnnouncement('.$newsDB['id'].')"></b></p>
                            </div>';
                        }
                        ?>
                        <?php else: ?>
                            There currently aren't any community announcements. Stay tuned for future updates.
                        <?php endif; ?>
                    </div>
                  </div>
              </div>
        </div>
    </div>
    <!-- CONTENT END -->
    <?php include 'inc/copyright.php'; ?>
    <?php include 'inc/page-bottom.php'; ?>

