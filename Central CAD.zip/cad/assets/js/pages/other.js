setInterval(function(){$.ajax({
    url: 'inc/backend/user/other/aopStatus.php',
    success: function(data) {
        var newAop = data;
        var oldAop = $('#updateAop').val();
        if(newAop != oldAop){

        } else {
            $('#updateAop').html(data);
            toastr.info('AOP was changed', 'System:');
        }
    }
});}, 5000);